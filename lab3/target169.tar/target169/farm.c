/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_471(unsigned *p)
{
    *p = 2425411666U;
}

unsigned getval_222()
{
    return 3284633960U;
}

unsigned addval_277(unsigned x)
{
    return x + 1925404726U;
}

unsigned getval_466()
{
    return 2428995912U;
}

unsigned addval_408(unsigned x)
{
    return x + 2428996936U;
}

unsigned getval_483()
{
    return 3281016854U;
}

unsigned getval_310()
{
    return 2428995912U;
}

void setval_156(unsigned *p)
{
    *p = 2425444513U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_452(unsigned x)
{
    return x + 3223372429U;
}

unsigned getval_271()
{
    return 3286272072U;
}

void setval_432(unsigned *p)
{
    *p = 3525362185U;
}

unsigned getval_331()
{
    return 2497743176U;
}

unsigned addval_168(unsigned x)
{
    return x + 3374894729U;
}

unsigned getval_161()
{
    return 3286272328U;
}

unsigned getval_424()
{
    return 3523793289U;
}

unsigned addval_413(unsigned x)
{
    return x + 3221799561U;
}

unsigned getval_340()
{
    return 3373843081U;
}

unsigned getval_322()
{
    return 3531129481U;
}

unsigned getval_453()
{
    return 3534016905U;
}

unsigned getval_368()
{
    return 3352201641U;
}

unsigned addval_386(unsigned x)
{
    return x + 3523268233U;
}

unsigned getval_491()
{
    return 3531915913U;
}

unsigned getval_414()
{
    return 2464188744U;
}

unsigned getval_112()
{
    return 3281113481U;
}

unsigned addval_416(unsigned x)
{
    return x + 3285092616U;
}

unsigned getval_446()
{
    return 3353381192U;
}

void setval_330(unsigned *p)
{
    *p = 3676360331U;
}

void setval_260(unsigned *p)
{
    *p = 3286272332U;
}

unsigned getval_227()
{
    return 3281043977U;
}

unsigned addval_144(unsigned x)
{
    return x + 3466149180U;
}

void setval_324(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_116()
{
    return 3523792521U;
}

void setval_499(unsigned *p)
{
    *p = 3252717896U;
}

void setval_339(unsigned *p)
{
    *p = 3526939033U;
}

unsigned addval_130(unsigned x)
{
    return x + 3680555401U;
}

void setval_253(unsigned *p)
{
    *p = 3281047945U;
}

unsigned getval_338()
{
    return 3526939021U;
}

unsigned getval_328()
{
    return 3526935049U;
}

unsigned getval_128()
{
    return 3674788225U;
}

void setval_233(unsigned *p)
{
    *p = 3380924040U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
